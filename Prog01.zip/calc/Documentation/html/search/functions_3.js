var searchData=
[
  ['func_0',['func',['../classcsc450lib_1_1calc_1_1_function1_d.html#a1b3425b98e60e712ec1e5cb02e8753c0',1,'csc450lib::calc::Function1D::func()'],['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html#a72ffa94aa6ba6fadd48079f97924aa51',1,'csc450lib::calc::PolynomialFunction1D::func(float x) const override']]],
  ['funchorner_1',['funcHorner',['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html#ac1e81db19e25d7b94c9989321b2695cb',1,'csc450lib::calc::PolynomialFunction1D']]]
];
