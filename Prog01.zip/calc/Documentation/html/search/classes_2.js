var searchData=
[
  ['polynomialfunction1d_0',['PolynomialFunction1D',['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html',1,'csc450lib::calc']]]
];
