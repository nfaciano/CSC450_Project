var searchData=
[
  ['getexpressionmma_0',['getExpressionMMA',['../classcsc450lib_1_1calc_1_1_function1_d.html#aada19880ea0adb19c0bf6221c4e6989e',1,'csc450lib::calc::Function1D::getExpressionMMA()'],['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html#a44378c7ab5f6a243ce4135b5fddfcc0b',1,'csc450lib::calc::PolynomialFunction1D::getExpressionMMA()']]],
  ['getlowerbound_1',['getLowerBound',['../classcsc450lib_1_1calc_1_1_function1_d.html#afe1d701b8855093f7b1d07858f682dc8',1,'csc450lib::calc::Function1D']]],
  ['getupperbound_2',['getUpperBound',['../classcsc450lib_1_1calc_1_1_function1_d.html#acef5cd8485478e00e186c40290a4b592',1,'csc450lib::calc::Function1D']]]
];
