var searchData=
[
  ['polynomialfunction1d_0',['PolynomialFunction1D',['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html',1,'csc450lib::calc::PolynomialFunction1D'],['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html#ac5290db8595ff90c49cdbb504bebb7ad',1,'csc450lib::calc::PolynomialFunction1D::PolynomialFunction1D(const std::vector&lt; float &gt; &amp;a)'],['../classcsc450lib_1_1calc_1_1_polynomial_function1_d.html#a0ce772b22a66b3a0a2e4345df816ff9a',1,'csc450lib::calc::PolynomialFunction1D::PolynomialFunction1D(const float *a, unsigned int n)']]]
];
