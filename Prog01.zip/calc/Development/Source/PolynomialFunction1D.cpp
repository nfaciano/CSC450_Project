#include "PolynomialFunction1D.h"
#include <sstream>

namespace csc450lib {
namespace calc {

PolynomialFunction1D::PolynomialFunction1D(const std::vector<float>& a) : coefficients(a) {}

PolynomialFunction1D::PolynomialFunction1D(const float* a, unsigned int n) : coefficients(a, a + n) {}

float PolynomialFunction1D::func(float x) const {
    float result = 0.0;
    float xPower = 1.0; // Start with x^0
    for (size_t i = 0; i < coefficients.size(); ++i) {
        result += coefficients[i] * xPower;
        xPower *= x; // Calculate the next power of x for the next iteration
    }
    return result;
}

float PolynomialFunction1D::funcHorner(float x) const {
    float result = coefficients.back();
    for (int i = coefficients.size() - 2; i >= 0; --i) {
        result = result * x + coefficients[i];
    }
    return result;
}

std::shared_ptr<std::string> PolynomialFunction1D::getExpressionMMA() const {
    std::stringstream ss;
    ss << coefficients[0];
    for (size_t i = 1; i < coefficients.size(); ++i) {
        ss << " + " << coefficients[i] << "*x^" << i;
    }
    return std::make_shared<std::string>(ss.str());
}

} // namespace calc
} // namespace csc450lib
